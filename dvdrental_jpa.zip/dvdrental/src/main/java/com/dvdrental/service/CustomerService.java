package com.dvdrental.service;

import com.dvdrental.service.model.Customer;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Service
public class CustomerService {
    @PersistenceContext
    private EntityManager entityManager;

    public List<Customer> findAll() {
        return entityManager.createQuery("select c from com.dvdrental.service.model.Customer c where 341 < customerId and customerId < 345").getResultList();
    }
}