package com.dvdrental.controller;

import com.dvdrental.controller.model.AddressDTO;
import com.dvdrental.controller.model.CustomerDTO;
import com.dvdrental.controller.model.PaymentDTO;
import com.dvdrental.service.CustomerService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@RestController
public class CustomerController {
    private CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    @GetMapping("/customers")
    public List<CustomerDTO> findAll() {
        return customerService.findAll().stream().map(
                customer ->
                    new CustomerDTO().toBuilder()
                            .id(customer.getCustomerId())
                            .firstName(customer.getFirstName())
                            .lastName(customer.getLastName())
                            .email(customer.getEmail())
                            .address(customer.getAddress() != null ? new AddressDTO().toBuilder()
                                    .id(customer.getAddress().getAddressId())
                                    .address(customer.getAddress().getAddress())
                                    .address2(customer.getAddress().getAddress2())
                                    .district(customer.getAddress().getDistrict())
                                    .build()
                                    :
                                    null)
                            .payments(customer.getPayments().stream().map(
                                            payment -> new PaymentDTO().toBuilder()
                                                    .id(payment.getPaymentId())
                                                    .amount(payment.getAmount())
                                                    .paymentDate(payment.getPaymentDate())
                                                    .build())
                                    .collect(Collectors.toList()))
                            .build()
                )
                .collect(Collectors.toList());
    }
}
