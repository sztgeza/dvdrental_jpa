package com.dvdrental.controller.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
public class AddressDTO {
    private Integer id;
    private String address;
    private String address2;
    private String district;
    private LocalDateTime lastUpdated;
}
